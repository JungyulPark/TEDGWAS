# TED-TRAP v5 — Manuscript Assets Lock Registry

**Purpose:** Track which manuscript tables/figures are verified and locked, with the
exact values, source files, and lock status. Nothing enters the manuscript unless it
appears here as LOCKED.

**Lock procedure:** Claude verifies values against source data → user approves →
status set to LOCKED → Gemini records file path + MD5 in this registry → asset frozen.

---

## STATUS LEGEND
- 🔄 IN PROGRESS — being verified/edited
- ✅ LOCKED — verified, approved, frozen (do not change without re-opening)

---

## MAIN TABLES

### Table 1 — Study design & data sources
- **Status:** ✅ LOCKED (2026-05-26)
- **Source:** hand-built (study metadata), no computed values
- **File:** `07_manuscript/tables/Table1_study_design.{html,png}` and `Table1_VALUES.csv`
- **Verified values (all ✅ correct):**
  - eQTLGen: EUR, 31,684 (→ "up to 31,684 participants"; rs179252 NrSamples=31,566)
  - BBJ Graves GCST90018627: EAS, 2,809 cases (discovery)
  - UKB hyperthyroid GCST90038636: EUR, 3,731 cases (replication)
  - FinnGen R12 GO: EUR, 858 cases (TED-specific sensitivity)
  - In-house orbital RNA-seq: Korean, 4 TED + 1 control
- **MD5:**
  - HTML: f595d88bc2485c08dd935ba383bc978a (size: 12274 bytes)
  - PNG: a07958406e016140ed816a386067bfcb (size: 82986 bytes)
  - CSV: 879a58cfdf85c39d3ece905a1918185a (size: 425 bytes)

### Table 2 — Integrated evidence for backbone genes
- **Status:** ✅ LOCKED (2026-05-26)
- **Source:** `TaskD_03d` (MR), `TaskE_01` (coloc), `TaskF_01` (tissue) — all ✅ Claude-verified
- **File:** `07_manuscript/tables/Table2_integrated_evidence.{html,png}` and `Table2_VALUES.csv`
- **Verified values (all ✅ correct, re-confirmed):**
  | Gene | MR BBJ | MR UKB | MR FinnGen | Coloc H4 BBJ/FinnGen | Tissue log2FC (padj) |
  |------|--------|--------|------------|----------------------|----------------------|
  | TSHR | −2.10 (1.1e-14) | −2.44 (8.8e-28) | −2.33 (2.8e-7) | 0.951/0.986 | +2.33 (0.032) |
  | IGF1R | +0.45 (0.021) | +0.30 (0.012) | +0.34 (0.182) | 0.043/0.036 | +0.41 (1.00 NS) |
  | CTLA4 | −1.74 (5.5e-15) | −1.57 (0.002) | −1.77 (0.012) | 0.206/0.978 | +1.27 (0.815 NS) |
- **MD5:**
  - HTML: 7b45adcbfe6b49fa47c874bd6a5891dd (size: 13430 bytes)
  - PNG: e948f45ae01fa9d0d6e7080be8574a98 (size: 92296 bytes)
  - CSV: 923db5eeb5f225e319563e22eac9bb22 (size: 568 bytes)

---

## MAIN FIGURES

### Figure 2 — MR volcano
- **Status:** ✅ LOCKED (2026-05-26)
- **Source:** `TaskD_03d` — ✅ verified (2,235 genes plotted, 13 Bonferroni hits)
- **File:** `07_manuscript/figures/Figure2_MR_volcano.{png,pdf}`
- **Verified:** TSHR/CTLA4 upper-left (protective, strong); IGF1R mid-low (nominal, below Bonferroni); 13 hits labeled; class colors correct; Bonferroni line at 1.965e-5. Plotted title displays "Druggable-gene-wide BBJ discovery MR".
- **MD5:**
  - PNG: ecfa7368a8a20826fe1ae05634bbe919 (size: 220210 bytes)
  - PDF: 0e8cd58e099f17b0971041b90794f67c (size: 129913 bytes)

### Figure 3 — TSHR vs IGF1R multi-modal composite
- **Status:** ✅ LOCKED (2026-05-26)
- **Source:** `TaskE_01` (coloc), `TaskD_03d` (MR), `TaskF_01` (tissue n=5) — all ✅
- **File:** `07_manuscript/figures/Figure3_TSHR_vs_IGF1R_composite.{png,pdf}`
- **Verified:** Panel A coloc (TSHR H4 green / IGF1R H2 orange [labeled: H2 (GWAS assoc. only)] / CTLA4 mixed); Panel B forest (TSHR/CTLA4 negative, IGF1R positive); Panel C tissue (TED n=4 + Control n=1, TSHR padj=3.2e-2). All values match source.
- **MD5:**
  - PNG: b388760c8f7468c1274121c6d4b10d13 (size: 233142 bytes)
  - PDF: 2892925f9785012e921228e84015df59 (size: 9713 bytes)

---

## CAPTIONS & TEXT

### Main Captions & Methods Sentences
- **Status:** ✅ LOCKED (2026-05-26)
- **File:** `07_manuscript/MAIN_CAPTIONS.md`
- **MD5:** 14291a6b0f1bba61e1ca7ff097d37b75 (size: 4941 bytes)

---

## SUPPLEMENTARY (built, pending verification/lock)
- S1 (13 hits), S2 (candidate coloc), S5 (chr16 cluster), S7 (MR sensitivity):
  R code written + logic verified by Claude; awaiting Gemini build + lock.
- S3 (fine-mapping), S6 (external GEO): pending Week1/GEO verification.
- S4 (instrument), S8 (STROBE-MR): to be built.

---

## LOCK LOG
| Date | Asset | Action | By |
|------|-------|--------|-----|
| 2026-05-26 | Table 1 | LOCKED — wording updated, rebuilt and MD5 registered | Claude+user |
| 2026-05-26 | Table 2 | LOCKED — wording updated, rebuilt and MD5 registered | Claude+user |
| 2026-05-26 | Fig 2   | LOCKED — title updated, rebuilt and MD5 registered | Claude+user |
| 2026-05-26 | Fig 3   | LOCKED — legend label updated, rebuilt and MD5 registered | Claude+user |
| 2026-05-26 | Captions| LOCKED — MAIN_CAPTIONS.md written and MD5 registered | Claude+user |

---

*Registry maintained as assets are verified. Manuscript draws only from LOCKED assets.*
